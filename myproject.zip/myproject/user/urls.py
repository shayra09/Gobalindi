from django.urls import path
from . import  views
urlpatterns =[
    path('',views.index),
    path('home/',views.index),
    path('about/',views.about),
    path('contact/',views.contact),
    path('faqs/',views.faqs),
    path('news/',views.news),
    path('videonews/',views.videonews),
    path('job/',views.job),
    path('newsdetails/',views.newsdetail),
    path('portfolio/',views.portfolio),
]